#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(shinydashboard)
library(plotly)
library(DT)
library(here)
library(forecast)
library(ggplot2)
library(dplyr)

if (!file.exists(here::here("apple_watch_dashboard", "global_vars.R"))) {
    source(here::here("global_vars.R"))
    print("using alternate")
} else {
    source(here::here("apple_watch_dashboard", "global_vars.R"))
}

# Load data frames
if (!file.exists(here::here("data/processed/rds_files", "ActiveEnergyBurned.rds"))) {
    # Receive file names available in directory
    file_names <- dir(path = here::here("rds_files"), pattern = '*.rds')
    
    # Add full path to file names
    files <- paste0(here::here("rds_files/"), file_names)
    
    # Read all files into a list utilizing purrr
    my_data <- files %>%
        purrr::map(readRDS)
    
    # set names and remove the `.rds` section of the strings
    names(my_data) <- file_names %>%
        str_replace(".rds", "")
} else {
    # Receive file names available in directory
    file_names <- dir(path = here::here("data/processed/rds_files"), pattern = "*.rds")
    
    # Add full path to file names
    files <- paste0(here::here("data/processed/rds_files"), "/", file_names)
    
    # Read all files into a list utilizing purrr
    my_data <- files %>%
        purrr::map(readRDS)
    
    # set names and remove the `.rds` section of the strings
    names(my_data) <- file_names %>%
        str_replace(".rds", "")
}

# Define colors for plotting 
clrs <- c("#d7ede8", "#9cd3c6", "#74c1af",
          "#39a78e", "#277463", "#164238",
          "#0b211c")

# More colors
more_clrs <- c("#f2d9df", "#ca637a", "#ba3f5b",
               "#943349", "#6e2636", "#230c11",
               "#060203")

# List containing respective dataframe
selectionOptions <- list("active_energy" = my_data[["ActiveEnergyBurned"]],
                         "basal_energy" = my_data[["BasalEnergyBurned"]],
                         "step_count" = my_data[["StepCount"]],
                         "dist_walk_run" = my_data[["DistanceWalkingRunning"]],
                         "flights_climbed" = my_data[["FlightsClimbed"]])

# Options for titles in plots
titleOptions <- list("active_energy" = "Active Energy \nBurned",
                     "basal_energy" = "Basal Energy \nBurned",
                     "step_count" = "Step Count",
                     "dist_walk_run" = "Distance Walking \nand Running",
                     "flights_climbed" = "Flights Climbed")

# Options for 
unitOptions <- list("active_energy" = "Calories",
                    "basal_energy" = "Calories",
                    "step_count" = "Steps",
                    "dist_walk_run" = "Miles",
                    "flights_climbed" = "Elevation Change")

# App
ui <- dashboardPage(
    dashboardHeader(title = "Sanford Health Hack - Seamless Health Data Integration",
                    titleWidth = 800),
    dashboardSidebar(
        # Add options to side bar
        sidebarMenu(
            #menuItem(
            fileInput("file1", "Choose CSV File",
                      multiple = TRUE,
                      accept = c("text/csv",
                                 "text/comma-separated-values,text/plain",
                                 ".csv")),
            
                selectInput("category", "Choose Category:",
                            c("Active Energy Burned" = "active_energy",
                              "Basal Energy Burned" = "basal_energy",
                              "Step Count" = "step_count",
                              "Distance Walking and Running" = "dist_walk_run",
                              "Flights Climbed" = "flights_climbed")),
                
                selectInput("category2", "Choose Comparitive Category:",
                            c("Active Energy Burned" = "active_energy",
                              "Basal Energy Burned" = "basal_energy",
                              "Step Count" = "step_count",
                              "Distance Walking and Running" = "dist_walk_run",
                              "Flights Climbed" = "flights_climbed")),
                
                selectInput("category3", "Choose Forecast Category:",
                            c("Active Energy Burned" = "active_energy",
                              "Basal Energy Burned" = "basal_energy",
                              "Step Count" = "step_count",
                              "Distance Walking and Running" = "dist_walk_run",
                              "Flights Climbed" = "flights_climbed")),
                sliderInput("slider", "Days to Forecast Ahead",0,30, 5, 1 )

            )
           # tags$ul()
        #)
    ),
    dashboardBody(
        # Aesthetical stuff related to CSS
        tags$head(tags$style(HTML('
        /* logo */
        .skin-blue .main-header .logo {
                                  background-color: #006b6f;
                                  font-family: Courier;
                                  }
        /* navbar (rest of the header) */
        .skin-blue .main-header .navbar {
                                  background-color: #00868B;
                                  }
        /* Wrapping list in sidebar */
        .sidebar-menu > ul {
                                  white-space: normal;
                                  padding-right: 30px;
                                  }'))),
        # First Row

        fluidRow(
            # Box for plotly time series plot
            box(
                plotlyOutput("time_series")
            ),
            # Box for plotly weekly time series plot
            box(
                plotlyOutput("time_series_weekly")
            ),
            
            fluidRow(
                # Box for plotly time series plot
                box(
                    plotOutput("forecast")
                ),
                box(
                    h4("Can You Beat The Odds?"),
                    tableOutput("forecastTable")
                ),
            fluidRow(
                    # Box for plotly time series plot
                    box(
                        h4("Past Performance"),
                        tableOutput("Performance")
                    ))
                )
        )
    )
)

# Define server logic required to render plots and table
server <- function(input, output) {
    output$heatmap <- renderPlot({
        my_input = input$category
        selectionOptions[[my_input]] %>%
            create_heatmap(creationDate, value, titleOptions[[my_input]])
    })
    output$weekday_table <- renderDataTable({
        my_input = input$category
        brks = seq(0, 5, 1)
        other_brks = seq(0, 30, 6)
        datatable(selectionOptions[[my_input]] %>%
                      calculate_missing_by_week(),
                  options = list(pageLength = 8)) %>%
            formatStyle(c("Sun", "Mon", "Tue",
                          "Wed", "Thu", "Fri", "Sat"), backgroundColor = styleInterval(brks, clrs)) %>%
            formatStyle(c("Total Missing"), backgroundColor = styleInterval(other_brks, more_clrs),
                        color = "white", fontWeight = "bold")
    })
    


    output$time_series <- renderPlotly({
        my_input = input$category
            b<- selectionOptions[[my_input]] %>%
               mutate(creationDate = str_sub(creationDate, end=10)) 
            aggregate(value~creationDate, b, sum)  %>% 
                create_time_series(value, unitOptions[[my_input]], titleOptions[[my_input]])
        
        
    })
    output$time_series_weekly2 <- renderPlotly({
        my_input = input$category
         selectionOptions[[my_input]] %>%
            
            create_time_series_weekly(value, unitOptions[[my_input]], titleOptions[[my_input]])
    })
    
    output$time_series_weekly<- renderPlotly({
        my_input = input$category
        my_input2 = input$category2
        
        cor1 <- selectionOptions[[my_input]] 
        cor2 <- selectionOptions[[my_input2]] 
        cor1 <- selectionOptions[[my_input]] %>%  
            mutate(creationDate = str_sub(creationDate, end=10))
        cor1 <- aggregate(value~creationDate, cor1, sum)  
        cor2 <- selectionOptions[[my_input2]] %>%  
            mutate(creationDate = str_sub(creationDate, end=10)) 
        cor2 <- aggregate(value~creationDate,cor2, sum) 
        cor <- merge(cor1, cor2, by = "creationDate")
        x <- list(
            title = unitOptions[[my_input]]
        )
        y <- list(
            title = unitOptions[[my_input2]]
        )
        plot_ly(data=  cor, x= ~value.x, y = ~value.y) %>% layout(xaxis = x, yaxis = y)

    })
    
    output$forecast <- renderPlot({
        my_input3 = input$category3
        cor1 <- selectionOptions[[my_input3]] %>%  
            mutate(creationDate = str_sub(creationDate, end=10))
        cor1 <- aggregate(value~creationDate, cor1, sum) 
        cor <- as.ts(cor1[,2])
        fit <- ets(cor)
        autoplot(forecast(fit, h = input$slider), main = "Your Forecast", xlab = "Days since first data", ylab = titleOptions[[my_input3]])
    })
    
    output$forecastTable <- renderTable({
        my_input3 = input$category3
        cor1 <- selectionOptions[[my_input3]] %>%  
            mutate(creationDate = str_sub(creationDate, end=10))
        cor1 <- aggregate(value~creationDate, cor1, sum) 
        cor <- as.ts(cor1[,2])
        fit <- ets(cor)
        df <- forecast(fit, h = input$slider)
        df <- as.data.frame(df)
        #df <- tibble::rownames_to_column(df, "Days Forward")
        df$Days_Forward <- 1:input$slider
        df
    })
    
    output$Performance <- renderTable({
        my_input3 = input$category3
        cor1 <- selectionOptions[["active_energy"]] %>%  
            mutate(creationDate = str_sub(creationDate, end=10))
        cor1 <- aggregate(value~creationDate, cor1, sum) 
        cor <- as.ts(cor1[1:(nrow(cor1)-input$slider),2])
        fit <- ets(cor)
        df <- forecast(fit, h = input$slider)
        df <- as.data.frame(df)
        df$Actual <- cor1[(nrow(cor1)-input$slider+1):nrow(cor1),2]
        #df <- tibble::rownames_to_column(df, "Days Forward")
        df$Days_Back <-input$slider:1
        df
    })
    
    
    

}

# Run the application
shinyApp(ui = ui, server = server)



